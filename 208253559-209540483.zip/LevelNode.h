#ifndef WET1_LEVELNODE_H
#define WET1_LEVELNODE_H

#include "Node.h"
#include "Player.h"

class LevelNode: public Node{
    Player* player;

public:
    LevelNode(int id, Player* player);
    ~LevelNode() override = default;
    LevelNode(const LevelNode& other) = default;
    LevelNode& operator=(const LevelNode& other) = default;
    Node* clone() override;
    bool operator<(const Node& second_node) const override;
    bool operator==(const Node& second_node) const override;
    int getExtraData() const override;
    Player* getPlayerInstance();
};
#endif //WET1_LEVELNODE_H
