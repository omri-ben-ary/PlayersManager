#include "EmptyNode.h"

EmptyNode::EmptyNode(): Node(0) {}

Node *EmptyNode::clone() {
    return new EmptyNode(*this);
}

int EmptyNode::getExtraData() const {
    return 0;
}

