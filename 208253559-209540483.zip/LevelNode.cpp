#include "LevelNode.h"

LevelNode::LevelNode(int id, Player* player): Node(id), player(player) {

}

Node *LevelNode::clone(){
    return new LevelNode(*this);
}

bool LevelNode::operator<(const Node& second_node) const {
    if(this->getExtraData() == second_node.getExtraData())
        return (second_node.getNodeKey() < this->getNodeKey());
    return (this->getExtraData() < second_node.getExtraData());
}

int LevelNode::getExtraData() const {
    return this->player->getLevel();
}

bool LevelNode::operator==(const Node &second_node) const {
    return ((this->getNodeKey() == second_node.getNodeKey()) && (this->getExtraData() == second_node.getExtraData()));
}

Player* LevelNode::getPlayerInstance() {
    return this->player;
}