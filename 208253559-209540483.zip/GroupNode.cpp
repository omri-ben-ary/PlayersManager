#include "GroupNode.h"

GroupNode::GroupNode(int id): Node(id), group(new Group(id)) {    //check if it is not a memory leak
}

GroupNode::GroupNode(int id, Group *new_group): Node(id), group(new_group) {

}

Node *GroupNode::clone() {
    return new GroupNode(*this);
}

int GroupNode::getExtraData() const {
    return this->group->getPlayersTree()->getSize();
}

Group* GroupNode::getGroup() {
    return this->group;
}

void GroupNode::setGroup(Group* group_to_set) {
    this->group = group_to_set;
}

